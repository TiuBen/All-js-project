import React, { useEffect, useState } from "react";
import useSWR from "swr";
import { SERVER_URL, FETCHER } from "@utils";
import Position from "./PositionSeatStaff/Position.jsx";
import { API_URL } from "../../../utils/const/Const.js";
import { data } from "autoprefixer";
import useStore from "../../../utils/store/userStore.js";

function DutyPage() {
    const { positions, isLoading, error, onDutyUsers } = useStore();
    if (error) return <div>failed to load</div>;
    if (isLoading) return <div>loading...</div>;

    return (
        <div className="flex flex-row flex-wrap gap-4 justify-start items-start  content-start overflow-auto p-2">
            {positions.map((item, index) => {
                return <Position key={index} {...item} />;
            })}
        </div>
    );
}

export default DutyPage;
