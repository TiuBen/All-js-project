import React from 'react'

function FilterToolBar() {
  return (
    <div>FilterToolBar</div>
  )
}

export default FilterToolBar